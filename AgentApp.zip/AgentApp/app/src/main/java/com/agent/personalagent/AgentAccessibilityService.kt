package com.agent.personalagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * خدمة وصول (Accessibility) تتيح للتطبيق قراءة عناصر الشاشة والتفاعل معها —
 * هذا الأسلوب نفسه الذي تستخدمه تطبيقات مثل Tasker وAutomate.
 *
 * ملاحظات أمان مهمة:
 * - المستخدم هو من يفعّل هذه الخدمة يدويًا من: الإعدادات → إمكانية الوصول،
 *   ويرى تحذيرًا صريحًا من أندرويد نفسه بأن هذه الصلاحية قوية وحساسة.
 * - يمكن تعطيلها بنفس الطريقة في أي لحظة.
 * - لا يوجد هنا أي كود يرسل بيانات الشاشة لأي خادم خارجي — كل التنفيذ محلي.
 */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AgentAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // يمكن لاحقًا مراقبة أحداث الشاشة هنا (تغيير نافذة، إشعار جديد...)
    }

    override fun onInterrupt() {}

    /** يفتح تطبيقًا آخر عبر اسم الحزمة (package name) */
    fun openAppByPackage(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
        return true
    }

    /** يبحث عن أول عنصر يحتوي النص المحدد ويضغط عليه */
    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, text) ?: return false
        return performClickOnNode(node)
    }

    /** يكتب نصًا في أول حقل إدخال قابل للتعديل موجود على الشاشة الحالية */
    fun typeInFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val editable = findEditableNode(root) ?: return false
        val arguments = android.os.Bundle()
        arguments.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            text
        )
        return editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /** نقرة على إحداثيات محددة على الشاشة (بديل عند تعذر إيجاد عنصر بالنص) */
    fun tapAt(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun performClickOnNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    private fun findNodeByText(
        root: AccessibilityNodeInfo,
        text: String
    ): AccessibilityNodeInfo? {
        val matches = root.findAccessibilityNodeInfosByText(text)
        return matches.firstOrNull()
    }

    private fun findEditableNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.isEditable) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val result = findEditableNode(child)
            if (result != null) return result
        }
        return null
    }
}
