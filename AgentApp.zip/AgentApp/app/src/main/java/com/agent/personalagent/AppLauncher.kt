package com.agent.personalagent

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager

/**
 * يبحث بين كل التطبيقات المثبتة فعليًا على الجهاز (وليس قائمة ثابتة بالكود)
 * ويطابق أقرب اسم لما قاله المستخدم، سواء بالعربي أو الإنجليزي، ثم يفتحه.
 */
class AppLauncher(private val activity: Activity) {

    data class InstalledApp(val label: String, val packageName: String)

    /** يجلب كل التطبيقات القابلة للفتح من الشاشة الرئيسية */
    private fun getLaunchableApps(): List<InstalledApp> {
        val pm = activity.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolved.mapNotNull { info ->
            val label = info.loadLabel(pm)?.toString() ?: return@mapNotNull null
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            InstalledApp(label, pkg)
        }.distinctBy { it.packageName }
    }

    /**
     * يبحث عن أفضل تطابق لاسم التطبيق المطلوب.
     * يجرب: تطابق كامل، ثم "يحتوي على"، ثم تشابه تقريبي (Levenshtein).
     */
    fun findBestMatch(spokenName: String): InstalledApp? {
        val apps = getLaunchableApps()
        if (apps.isEmpty()) return null

        val query = spokenName.trim().lowercase()

        apps.firstOrNull { it.label.trim().lowercase() == query }?.let { return it }
        apps.firstOrNull { it.label.trim().lowercase().contains(query) }?.let { return it }
        apps.firstOrNull { query.contains(it.label.trim().lowercase()) }?.let { return it }

        return apps.minByOrNull { levenshtein(it.label.trim().lowercase(), query) }
            ?.takeIf { levenshtein(it.label.trim().lowercase(), query) <= 4 }
    }

    fun open(app: InstalledApp): Boolean {
        val launchIntent = activity.packageManager.getLaunchIntentForPackage(app.packageName)
            ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(launchIntent)
        return true
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = if (a[i - 1] == b[j - 1]) {
                    dp[i - 1][j - 1]
                } else {
                    1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
                }
            }
        }
        return dp[a.length][b.length]
    }
}
