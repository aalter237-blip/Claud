package com.agent.personalagent

import android.app.Activity
import android.content.Intent
import android.provider.AlarmClock
import android.net.Uri
import java.util.regex.Pattern

/**
 * محرك بسيط لتفسير الأوامر النصية وتحويلها إلى إجراءات نظام.
 * كل الإجراءات تفتح نوايا (Intents) رسمية لتطبيقات النظام (الساعة، الرسائل، ...)
 * بدلاً من تنفيذها بصمت — بهذا الشكل يبقى المستخدم هو من يؤكد كل خطوة حساسة،
 * وهذا مطلوب أيضًا لقبول التطبيق على متجر جوجل بلاي.
 */
class CommandDispatcher(private val activity: Activity) {

    private val appLauncher = AppLauncher(activity)

    sealed class Result {
        data class Success(val message: String) : Result()
        data class NotUnderstood(val original: String) : Result()
    }

    fun dispatch(rawCommand: String): Result {
        val text = rawCommand.trim()

        // 1) ضبط منبه: "اضبط منبه الساعة 7:30" أو "منبه 07:30"
        val alarmMatch = Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(text)
        if (text.contains("منبه") && alarmMatch.find()) {
            val hour = alarmMatch.group(1)!!.toInt()
            val minute = alarmMatch.group(2)!!.toInt()
            return setAlarm(hour, minute, text)
        }

        // 2) منبه بعد X دقيقة/ثانية: "اضبط منبه بعد 5 دقايق"
        val afterMinutesMatch = Pattern.compile("بعد\\s*(\\d+)\\s*دقيق").matcher(text)
        if (text.contains("منبه") && afterMinutesMatch.find()) {
            val minutesFromNow = afterMinutesMatch.group(1)!!.toInt()
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.MINUTE, minutesFromNow)
            return setAlarm(
                cal.get(java.util.Calendar.HOUR_OF_DAY),
                cal.get(java.util.Calendar.MINUTE),
                text
            )
        }

        // 3) إرسال رسالة: "ارسل رسالة الى 0555555555 تقول مرحبا"
        val msgMatch = Pattern.compile("(?:ارسل|أرسل)\\s*رسال[ةه]?\\s*(?:الى|إلى)?\\s*([+0-9]{6,15})\\s*(?:تقول|نصها|:)?\\s*(.*)").matcher(text)
        if (msgMatch.find()) {
            val number = msgMatch.group(1) ?: ""
            val body = msgMatch.group(2) ?: ""
            return openMessageApp(number, body)
        }

        // 4) فتح موقع محدد: "افتح موقع يوتيوب" أو "افتح موقع youtube.com"
        val siteMatch = Pattern.compile("افتح\\s*موقع\\s*(.+)").matcher(text)
        if (siteMatch.find()) {
            return openWebsite(siteMatch.group(1)?.trim() ?: "")
        }

        // 5) فتح أي تطبيق مثبت فعليًا بالاسم: "افتح واتساب" / "افتح انستقرام" / "افتح الكاميرا"
        val openAppMatch = Pattern.compile("افتح\\s+(.+)").matcher(text)
        if (openAppMatch.find()) {
            return openAnyApp(openAppMatch.group(1)?.trim() ?: "")
        }

        // 5) اضغط على عنصر بالنص عبر Accessibility: "اضغط على زر إرسال"
        val clickMatch = Pattern.compile("(?:اضغط|اضغطي)\\s*(?:على)?\\s*(.+)").matcher(text)
        if (clickMatch.find()) {
            return clickByAccessibility(clickMatch.group(1)?.trim() ?: "")
        }

        // 6) اكتب نص في الحقل المفتوح: "اكتب مرحبا كيف حالك"
        val typeMatch = Pattern.compile("(?:اكتب|اكتبي)\\s+(.+)").matcher(text)
        if (typeMatch.find()) {
            return typeByAccessibility(typeMatch.group(1)?.trim() ?: "")
        }

        // 7) الرجوع/الهوم عبر Accessibility
        if (text.contains("ارجع") || text.contains("رجوع")) {
            return globalAction { it.goBack() }
        }
        if (text.contains("الرئيسية") || text == "هوم") {
            return globalAction { it.goHome() }
        }

        return Result.NotUnderstood(text)
    }

    /** يحتاج تفعيل خدمة Accessibility مسبقًا من المستخدم */
    private fun clickByAccessibility(label: String): Result {
        val service = AgentAccessibilityService.instance
            ?: return Result.Success("يجب تفعيل صلاحية إمكانية الوصول أولاً من الإعدادات")
        return if (service.clickByText(label)) {
            Result.Success("تم الضغط على \"$label\"")
        } else {
            Result.Success("لم أجد عنصر بعنوان \"$label\" على الشاشة الحالية")
        }
    }

    private fun typeByAccessibility(content: String): Result {
        val service = AgentAccessibilityService.instance
            ?: return Result.Success("يجب تفعيل صلاحية إمكانية الوصول أولاً من الإعدادات")
        return if (service.typeInFocusedField(content)) {
            Result.Success("تم كتابة النص")
        } else {
            Result.Success("لم أجد حقل إدخال نشط لأكتب فيه")
        }
    }

    private fun globalAction(action: (AgentAccessibilityService) -> Boolean): Result {
        val service = AgentAccessibilityService.instance
            ?: return Result.Success("يجب تفعيل صلاحية إمكانية الوصول أولاً من الإعدادات")
        return if (action(service)) Result.Success("تم") else Result.Success("تعذر التنفيذ")
    }

    private fun setAlarm(hour: Int, minute: Int, original: String): Result {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "منبه من المساعد الشخصي")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false) // نعرض تطبيق الساعة للتأكيد
        }
        return if (intent.resolveActivity(activity.packageManager) != null) {
            activity.startActivity(intent)
            Result.Success("تم فتح تطبيق الساعة لضبط المنبه على %02d:%02d".format(hour, minute))
        } else {
            Result.Success("لا يوجد تطبيق ساعة يدعم هذا الإجراء على الجهاز")
        }
    }

    private fun openMessageApp(number: String, body: String): Result {
        val uri = Uri.parse("smsto:$number")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", body)
        }
        return if (intent.resolveActivity(activity.packageManager) != null) {
            activity.startActivity(intent)
            Result.Success("تم فتح تطبيق الرسائل جاهزًا للإرسال إلى $number")
        } else {
            Result.Success("لا يوجد تطبيق رسائل على الجهاز")
        }
    }

    private fun openWebsite(name: String): Result {
        if (name.isBlank()) return Result.Success("قل لي اسم الموقع اللي تبيه")

        // خريطة صغيرة لأشهر المواقع بأسمائها العربية الشائعة
        val known = mapOf(
            "يوتيوب" to "https://www.youtube.com",
            "youtube" to "https://www.youtube.com",
            "جوجل" to "https://www.google.com",
            "google" to "https://www.google.com",
            "تويتر" to "https://twitter.com",
            "اكس" to "https://twitter.com",
            "انستقرام" to "https://www.instagram.com",
            "انستجرام" to "https://www.instagram.com",
            "فيسبوك" to "https://www.facebook.com",
            "واتساب ويب" to "https://web.whatsapp.com"
        )

        val url = when {
            known.containsKey(name.lowercase()) -> known[name.lowercase()]!!
            name.contains(".") -> if (name.startsWith("http")) name else "https://$name"
            else -> "https://www.google.com/search?q=${Uri.encode(name)}"
        }

        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return Result.Success("تم فتح $name")
    }

    /** يحاول فتح أي تطبيق مثبت فعليًا بالاسم؛ ولو ما لقاه يجرب اختصارات النظام
     *  المعروفة (كاميرا/متصفح/خرائط)، ولو فشل كل شي يبحث عنه في جوجل كحل أخير */
    private fun openAnyApp(name: String): Result {
        if (name.isBlank()) return Result.Success("قل لي اسم التطبيق اللي تبيه")

        val match = appLauncher.findBestMatch(name)
        if (match != null && appLauncher.open(match)) {
            return Result.Success("تم فتح ${match.label}")
        }

        val fallback = openKnownApp(name)
        if (fallback is Result.Success) return fallback

        return openWebsite(name)
    }

    private fun openKnownApp(text: String): Result {
        val map = mapOf(
            "كاميرا" to "android.media.action.IMAGE_CAPTURE",
            "متصفح" to null, // سيُعامل خصيصًا
            "خرائط" to null
        )
        return when {
            text.contains("كاميرا") -> {
                activity.startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                Result.Success("تم فتح الكاميرا")
            }
            text.contains("متصفح") -> {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
                Result.Success("تم فتح المتصفح")
            }
            text.contains("خرائط") -> {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0")))
                Result.Success("تم فتح تطبيق الخرائط")
            }
            else -> Result.NotUnderstood(text)
        }
    }
}
