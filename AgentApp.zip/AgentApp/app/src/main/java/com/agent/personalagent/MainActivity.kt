package com.agent.personalagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dispatcher: CommandDispatcher
    private lateinit var voiceController: VoiceController
    private var isVoiceModeOn = false

    private val micPermissionCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dispatcher = CommandDispatcher(this)

        val input = findViewById<EditText>(R.id.commandInput)
        val resultText = findViewById<TextView>(R.id.resultText)
        val runButton = findViewById<Button>(R.id.runButton)
        val quickAlarmButton = findViewById<Button>(R.id.quickAlarmButton)
        val quickMessageButton = findViewById<Button>(R.id.quickMessageButton)
        val enableAccessibilityButton = findViewById<Button>(R.id.enableAccessibilityButton)
        val voiceToggleButton = findViewById<Button>(R.id.voiceToggleButton)
        val voiceStatus = findViewById<TextView>(R.id.voiceStatus)

        runButton.setOnClickListener {
            val command = input.text.toString()
            if (command.isBlank()) {
                Toast.makeText(this, "اكتب أمرًا أولاً", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            resultText.text = executeCommand(command)
        }

        quickAlarmButton.setOnClickListener {
            resultText.text = executeCommand("اضبط منبه بعد 1 دقيقة")
        }

        quickMessageButton.setOnClickListener {
            resultText.text = executeCommand("ارسل رسالة الى 0500000000 تقول مرحبا")
        }

        enableAccessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // ---- الجزء الصوتي ----
        voiceController = VoiceController(
            activity = this,
            onCommand = { spokenText ->
                runOnUiThread {
                    input.setText(spokenText)
                    resultText.text = "🎤 سمعت: \"$spokenText\""
                }
                executeCommand(spokenText)
            },
            onStateChanged = { listening ->
                runOnUiThread {
                    voiceStatus.text = if (listening) "🔴 يسمع..." else "🟢 بانتظار كلمة \"شرقاوي\"..."
                }
            }
        )
        voiceController.init()

        voiceToggleButton.setOnClickListener {
            if (!isVoiceModeOn) {
                if (hasMicPermission()) {
                    startVoiceMode(voiceToggleButton, voiceStatus)
                } else {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.RECORD_AUDIO),
                        micPermissionCode
                    )
                }
            } else {
                stopVoiceMode(voiceToggleButton, voiceStatus)
            }
        }
    }

    private fun startVoiceMode(button: Button, statusView: TextView) {
        isVoiceModeOn = true
        button.text = "⏹ إيقاف الاستماع"
        statusView.text = "🟢 بانتظار كلمة \"شرقاوي\"..."
        voiceController.startContinuousListening()
    }

    private fun stopVoiceMode(button: Button, statusView: TextView) {
        isVoiceModeOn = false
        button.text = "🎤 فعّل الاستماع لكلمة (شرقاوي)"
        statusView.text = "غير نشط"
        voiceController.stopContinuousListening()
    }

    private fun executeCommand(command: String): String {
        return when (val result = dispatcher.dispatch(command)) {
            is CommandDispatcher.Result.Success -> result.message
            is CommandDispatcher.Result.NotUnderstood ->
                "لم أفهم الأمر: \"${result.original}\""
        }
    }

    private fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micPermissionCode &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            val button = findViewById<Button>(R.id.voiceToggleButton)
            val statusView = findViewById<TextView>(R.id.voiceStatus)
            startVoiceMode(button, statusView)
        } else {
            Toast.makeText(this, "لازم إذن الميكروفون عشان يشتغل الوضع الصوتي", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        val statusView = findViewById<TextView>(R.id.accessibilityStatus)
        val enabled = AgentAccessibilityService.instance != null
        statusView.text = if (enabled) {
            "✅ صلاحية التحكم بالشاشة مفعّلة"
        } else {
            "⚠️ صلاحية التحكم بالشاشة غير مفعّلة — اضغط الزر أعلاه وفعّلها من القائمة"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceController.release()
    }
}
