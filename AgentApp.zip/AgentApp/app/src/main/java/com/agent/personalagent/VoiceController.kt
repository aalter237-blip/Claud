package com.agent.personalagent

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/**
 * يدير الاستماع المستمر (بدون لمس الشاشة) والرد الصوتي.
 * يعمل بدورة: استمع → نفّذ الأمر → انطق النتيجة → استمع مرة أخرى تلقائيًا.
 */
class VoiceController(
    private val activity: AppCompatActivity,
    private val onCommand: (String) -> String, // يستقبل النص المسموع ويرجّع رسالة النتيجة
    private val onStateChanged: (listening: Boolean) -> Unit,
    private val wakeWord: String = "شرقاوي"
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var continuousMode = false
    private var ttsReady = false

    /** لو true معناها التطبيق سامعك الآن وينتظر الأمر نفسه (بعد ما قلت "شرقاوي") */
    private var awaitingCommand = false

    fun init() {
        tts = TextToSpeech(activity) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.language = Locale("ar")
        }
    }

    /** يبدأ وضع الاستماع الدائم لكلمة التنبيه "شرقاوي" */
    fun startContinuousListening() {
        continuousMode = true
        awaitingCommand = false
        listenOnce()
    }

    fun stopContinuousListening() {
        continuousMode = false
        awaitingCommand = false
        recognizer?.stopListening()
        recognizer?.destroy()
        recognizer = null
        onStateChanged(false)
    }

    private fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
            speak("التعرف الصوتي غير مدعوم على هذا الجهاز")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(activity).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onStateChanged(true)
                }

                override fun onResults(results: Bundle?) {
                    onStateChanged(false)
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    handleHeardText(text)
                }

                override fun onError(error: Int) {
                    onStateChanged(false)
                    // نتجاهل أخطاء "ما فيه كلام" ونعيد المحاولة تلقائيًا بوضع الاستماع المستمر
                    if (continuousMode) listenOnce()
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            startListening(intent)
        }
    }

    /**
     * منطق كلمة التنبيه:
     * - لو التطبيق بوضع "انتظار الأمر" (بعد ما سمع "شرقاوي" سابقًا بدون أمر معه)،
     *   يعتبر أي كلام تالي هو الأمر نفسه وينفذه مباشرة.
     * - غير هيك، يفحص هل الكلام يحتوي كلمة التنبيه:
     *   - لو معها أمر بنفس الجملة ("يا شرقاوي افتح واتساب") ينفذ الأمر فورًا.
     *   - لو كلمة التنبيه لحالها ("شرقاوي") يرد "قل أمرك" وينتظر الجملة التالية.
     * - لو ما فيه كلمة التنبيه إطلاقًا، يتجاهل الكلام تمامًا ويرجع يستمع بصمت
     *   (بدون أي رد صوتي) — عشان ما يستجيب لأي كلام عرضي حواليك.
     */
    private fun handleHeardText(text: String?) {
        if (text.isNullOrBlank()) {
            if (continuousMode) listenOnce()
            return
        }

        if (awaitingCommand) {
            awaitingCommand = false
            runCommand(text)
            return
        }

        val normalized = text.trim()
        val wakeIndex = normalized.indexOf(wakeWord)
        if (wakeIndex == -1) {
            // ما فيه كلمة التنبيه — تجاهل صامت وارجع استمع
            if (continuousMode) listenOnce()
            return
        }

        val remainder = normalized.replace(wakeWord, "").trim()
        if (remainder.isNotEmpty()) {
            runCommand(remainder)
        } else {
            awaitingCommand = true
            speak("قل أمرك") {
                if (continuousMode) listenOnce()
            }
        }
    }

    private fun runCommand(command: String) {
        val resultMessage = onCommand(command)
        speak(resultMessage) {
            if (continuousMode) listenOnce()
        }
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady || tts == null) {
            onDone?.invoke()
            return
        }
        val utteranceId = "agent_utt_${System.currentTimeMillis()}"
        if (onDone != null) {
            tts?.setOnUtteranceProgressListener(object :
                android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    onDone()
                }
                override fun onError(utteranceId: String?) {
                    onDone()
                }
            })
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun release() {
        continuousMode = false
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
